
@include('layout.header')
@yield('main-content')
@include('layout.footer')

