




<!-- Page Header Start here -->
<section class="page-header section-notch">
    <div class="overlay">
        <div class="container">
        <h3>Our School</h3>
        <ul>
            <li><a href="../../index.html">Home /</a></li>
            <li>About / Our School</li>
        </ul>
        </div><!-- container -->
    </div><!-- overlay -->
    </section><!-- page header -->
    <!-- Page Header End here -->


    <!-- Blog Post Start here -->
          <section class="blog-post padding-120">
          <div class="container">
            <div class="row">

              <div class="col-lg-12">
                <div class="single-post ">








                                                                          <div class="post-content">
                                          <div class="post-image">
                                              <center><img src="../../storage/Menus/About/3/9.jpg" alt="post image" class="img-responsive"></center>
                                          </div>
                                          <h3>BPSN Overview</h3>
                                          <p>
                                              <p>In the changing scenario of education, there is no field left untouched by stiff competition. Armed with excellent infrastructure and educational facilities, Blossom Public School(New) is an ideal choice for parents seeking a qualitative educational institution for their children. JSPM provides a pollution free environment with complete personalized attention for its students. After all quality in education leads to a higher quality in life and that is what we at JSPM are constantly striving for.</p>

    <p><strong>Introduction</strong></p>

    <p>Establishment year 1998.<br />
    Registered under BPT Act and Society Act.<br />
    Founder, Promoters and Directors are from educational and professional fields.</p>
                                          </p>
                                        </div>










                </div><!-- single post -->
              </div>

            </div>
          </div>
        </section>
      <!-- Blog Post End here -->
