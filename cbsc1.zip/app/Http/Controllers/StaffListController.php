<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StaffListController extends Controller
{
    public function index(){
        return view('pages.about.stafflist');
    }
}
