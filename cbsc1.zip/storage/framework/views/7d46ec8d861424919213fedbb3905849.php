<!-- <script>
  document.getElementById("mySliderSection").style.minHeight = "800px";
</script> -->
<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>


  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Pune&#39; Cambridge</title>

  <link href="#" rel="shortcut icon" type="image/vnd.microsoft.icon" />

  <!-- Google fonts -->
  <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

  <!-- Bootstrap -->
  <link href="kidsacade/assets/css/bootstrap.min.css" rel="stylesheet">

  <!-- Font-awesome -->
  <link href="kidsacade/assets/css/font-awesome.min.css" rel="stylesheet">

  <!-- Flaticon -->
  <link href="kidsacade/assets/flaticon/flaticon.css" rel="stylesheet">

  <!-- lightcase -->
  <link href="kidsacade/assets/css/lightcase.css" rel="stylesheet">

  <!-- Swiper -->
  <link href="kidsacade/assets/css/swiper.min.css" rel="stylesheet">

  <!-- quick-view -->
  <link href="kidsacade/assets/css/quick-view.css" rel="stylesheet">

  <!-- nstSlider -->
  <link href="kidsacade/assets/css/jquery.nstSlider.css" rel="stylesheet">

  <!-- flexslider -->
  <link href="kidsacade/assets/css/flexslider.css" rel="stylesheet">

  <!--  rtl  -->
  <link href="kidsacade/assets/css/rtl.css" rel="stylesheet">

  <!-- Style -->
  <link href="kidsacade/assets/css/style.css" rel="stylesheet">

  <link href="css/custom.css" rel="stylesheet">

  <!-- Responsive -->
  <link href="kidsacade/assets/css/responsive.css" rel="stylesheet">

</head>

<body id="scroll-top">

  <!-- Preloader start here -->

  <div id="loader-wrapper">
    <div id="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
  </div>
  <!-- Preloader end here -->

  <!-- mobile menu start here -->
  <div class="mobile-menu-area">
    <div class="logo-area">
      <a style="max-width:175px" class="logo" href="index.html"><img
          src="storage/Homepage/Footer/Contact/1600260291bpsn_logo.png" alt="logo" class="img-responsive"></a>
      <button type="button" class="navbar-toggle collapsed d-md-none" data-toggle="collapse"
        data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>

    <div class="mobile-menu">
      <ul class="m-menu">
        <li class="dropdown-submenu">
          <a href="#">Home</a>

        </li>
        <li class="dropdown-submenu">
          <a href="#">About</a>
          <!-- <ul class="mobile-submenu">
                              <li><a href="About/about_display/1.html">Our Organization </a></li>
                  <li><a href="About/about_display/2.html">Founder Secretary&#039;s Message </a></li>
                  <li><a href="About/about_display/3.html">Our School </a></li>
                  <li><a href="About/about_display/4.html">Vision  and Mission </a></li>
                  <li><a href="About/about_display/5.html">Principal&#039;s Message </a></li>
                  <li><a href="About/about_display/6.html">Managing Committee </a></li>
                  <li><a href="About/about_display/7.html">Self-Affidavit </a></li>
                  <li><a href="About/about_display/8.html">Affiliation </a></li>
                  <li><a href="About/about_display/9.html">Annual Report </a></li>
                  <li><a href="About/about_display/12.html">Circular </a></li>
                  <li><a href="About/about_display/11.html">Collaborations </a></li>
                  <li><a href="About/about_display/14.html">Staff List </a></li>
                  <li><a href="About/about_display/13.html">MANDATORY PUBLIC DISCLOSURE </a></li>

          <li><a href="campus_details.html"> Our Campuses </a></li>
          <li><a href="About/about_display.html"> Our Team </a></li>
          </ul> -->
        </li>

        <li class="dropdown-submenu">
          <a href="#">Admission</a>
          <!-- <ul class="mobile-submenu">
                                            <li><a href="Admission/admission_page_display/6.html">Admission Enquiry </a></li>
                              <li><a href="Admission/admission_page_display/1.html">Admission Procedure &amp; Age Criteria </a></li>
                              <li><a href="Admission/admission_page_display/2.html">Document Checklist </a></li>
                              <li><a href="Admission/admission_page_display/8.html">Short Term Certified Courses for International Students </a></li>
                              <li><a href="Admission/admission_page_display/3.html">School Brochure </a></li>
                              <li><a href="Admission/admission_page_display/7.html">XI Science Brochure </a></li>
                              <li><a href="Admission/admission_page_display/4.html">Fee Details </a></li>
                        </ul> -->
        </li>

        <li class="dropdown-submenu">
          <a href="#">Academics</a>
          <!-- <ul class="mobile-submenu">
                                            <li><a href="Academic/academic_page_display/1.html">Curriculum Details </a></li>
                              <li><a href="Academic/academic_page_display/2.html">Learning Resources </a></li>
                              <li><a href="Academic/academic_page_display/3.html">School Best Practice </a></li>
                              <li><a href="Academic/academic_page_display/4.html">Academic Calendar </a></li>
                              <li><a href="Academic/academic_page_display/13.html">BPSN Newsletter </a></li>
                              <li><a href="Academic/academic_page_display/5.html">Environmental Education </a></li>
                              <li><a href="Academic/academic_page_display/6.html">Student Services </a></li>
                              <li><a href="Academic/academic_page_display/15.html">Book List </a></li>
                              <li><a href="Academic/academic_page_display/12.html">Holiday List </a></li>
                              <li><a href="Academic/academic_page_display/16.html">Student Strength 2024-2025 </a></li>
                              <li><a href="Academic/academic_page_display/8.html">Teachers Training Details </a></li>
                              <li><a href="Academic/academic_page_display/10.html">Alumni Association </a></li>
                            <li><a href="#">Enrichment Activities</a>
                <ul class="dropdown-menu">
                                          <li><a href ="Academic/activity_page_display/1.html">Co-Curricular Activities</a></li>
                                          <li><a href ="Academic/activity_page_display/2.html">Extra-Curricular Activities</a></li>
                                          <li><a href ="Academic/activity_page_display/4.html">Celebrations</a></li>
                                      </ul>
              </li>
                <li><a href="#">Academic Achievements</a>
                <ul class="dropdown-menu">
                                          <li><a href ="Academic/achievement_page_display/1.html">School Achievements</a></li>
                                          <li><a href ="Academic/achievement_page_display/2.html">Faculty Achievements</a></li>
                                          <li><a href ="Academic/achievement_page_display/3.html">Student Achievements</a></li>
                                      </ul>
              </li>
          </ul> -->
        </li>

        <li class="dropdown-submenu">
          <a href="#">Facilities</a>
          <!-- <ul class="mobile-submenu">
                                              <li><a href="Facility/facility_page_display/1.html">Laboratories</a></li>
                                <li><a href="Facility/facility_page_display/2.html">School Facilities</a></li>

              <li><a href="#" target="_blank">Digital Library</a></li>
          </ul> -->
        </li>

        <li class="dropdown-submenu">
          <a href="#">Gallery</a>
          <!-- <ul class="mobile-submenu">
                <li><a href="Gallery/photo_gallery_display.html">Gallery </a></li>
                <li><a href="Gallery/video_gallery_display.html">Video Gallery </a></li>
                <li><a href="Gallery/press_releases_display.html">Press Releases </a></li>
          </ul> -->
        </li>
        <li><a href="Contact/contact.html">Contact</a></li>

      </ul>
    </div>
  </div>
  <!-- mobile menu ending here -->

  <header class="header-two">
    <div class="header-top">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <a class="logo" href="index.html"><img style="float: left;"
                src="storage/Homepage/Footer/Contact/1600256287bpsn.png" alt="logo" class="img-responsive"></a>
          </div>
          <div class="col-md-5">
            <center style="margin-left: -145px;">
              <h3 class="school_name"> Pune&#039; Cambridge</h3>
              <span class="school_addr">Ambegaon</span> <br>
              <span class="school_grade"> <b> AFFILIATED TO CBSE </b></span>
            </center>
          </div>
          <div class="col-md-3">
            <ul class="top-contents">
              <li>
                <i class="icon flaticon-phone-call"></i>
                <div class="content">
                  <p style='font-size:15px'>Call Us </p>
                  <span style='font-size:15px'> 020-0000000000/00 </span>
                </div>
              </li>
              <li>
                <i class="icon flaticon-alarm-clock"></i>
                <div class="content" style=' margin-right: 15px;'>
                  <p style='font-size:15px'>School Timing</p>
                  <span style='font-size:15px'> 7:50AM - 2:30PM</span>
                </div>
              </li>
            </ul>
          </div>
        </div><!-- row -->
      </div><!-- container -->
    </div><!-- header top -->
    <style>
      /* Define a CSS class for the blinking animation */
      @keyframes blink {
        0% {
          background-color: yellow;
          /* Start with yellow background */
          color: black;
          /* Text color */
        }

        50% {
          background-color: transparent;
          /* Halfway, make it transparent */
          color: yellow;
          /* Text color */
        }

        100% {
          background-color: yellow;
          /* Back to yellow background */
          color: black;
          /* Text color */
        }
      }

      /* Apply the animation to the button with the blinking-button class */
      .blinking-button {
        animation: blink 2s infinite;
        /* Adjust the duration as needed */
      }
    </style>

    <div class="main-menu">
      <div class="container-fluide">
        <div class="row no-gutters">
          <nav class="main-menu-area w-100">
            <div class="logo-area d-md-none">
              <a style="max-width:195px;padding:10px;" class="logo" href="index.html"><img
                  src="storage/Homepage/Footer/Contact/1600260291bpsn_logo.png" alt="logo" class="img-responsive"></a>

              <button type="button" class="navbar-toggle collapsed d-md-none" data-toggle="collapse"
                data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
            </div>

            <div class="menu-area w-100">
              

              <ul class="menu">
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                    aria-expanded="false">Home
                    
                </a>
                  
                </li>


                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                    aria-expanded="false">About <span class="caret"></span></a>
                  
                </li>
                <li><a href="About/about_display/13.html">Mandatory Public Disclosure</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                    aria-expanded="false">Admissions <span class="caret"></span></a>
                  
                </li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                    aria-expanded="false">Academics <span class="caret"></span></a>
                  
                </li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                    aria-expanded="false">Facilities <span class="caret"></span></a>
                  
                </li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                    aria-expanded="false">Gallery <span class="caret"></span></a>
                  
                </li>
                <li><a href="Contact/contact.html">Contact</a></li>
              </ul>

            </div>
          </nav>
        </div>
      </div>
    </div>
  </header>




  <script src="../cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
  <script src="../maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" type="text/javascript"></script>

  

  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        <div class="modal-body">
          <div class="modal-header">
            <center>
              <h4 class="modal-title">Admission Notification</h4>
            </center>
          </div>

          

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
  </div>

  <script src="../ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="../unpkg.com/sweetalert%402.1.2/dist/sweetalert.min.js"></script>
  
<?php /**PATH E:\CBSC\cbsclaravel\cbsc\resources\views/layout/header.blade.php ENDPATH**/ ?>