<?php $__env->startSection('main-content'); ?>


<style>
    .sl{
        width: 100px;
    }
    td{
        text-align: center;
    }
</style>

<!-- Page Header Start here -->
<section class="page-header section-notch">
    <div class="overlay">
        <div class="container">
            <h3>MANDATORY PUBLIC DISCLOSURE</h3>
            <ul>
                <li><a href="<?php echo e(url('/')); ?>">Home /</a></li>
                <li>About / MANDATORY PUBLIC DISCLOSURE</li>
            </ul>
        </div><!-- container -->
    </div><!-- overlay -->
</section><!-- page header -->
<!-- Page Header End here -->


<!-- Blog Post Start here -->
<section class="blog-post padding-120">
    <div class="container">
        <div class="row">

            <div class="col-lg-12">
                <div class="single-post ">








                    <div class="post-content">
                        <h3>A. GENERAL INFORMATION:</h3>
                        <p>
                        <table border="1">
                            <tbody>
                                <tr>
                                    <td class="sl">SL NO.</td>
                                    <td>INFORMATION</td>
                                    <td>DETAILS</td>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>NAME OF THE SCHOOL</td>
                                    <td>Pune Cambridge Public School, Ambegaon</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>AFFILIATION NO</td>
                                    <td>UDISE - 27251600131</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>SCHOOL CODE</td>
                                    <td>-</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>COMPLETE ADDRESS</td>
                                    <td>Pune Cambridge Public School, Sr. No 28. Jijamata chowk, Behind Ambegaon Pathar
                                        Police Chowki, Ambegaon Pathar- Pune 411046</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>PRINCIPAL NAME</td>
                                    <td>Yeshwant B. Chitalkar</td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>PRINCIPAL QUALIFICATION</td>
                                    <td>M.A. B.ED, DSM, MBA</td>
                                </tr>
                                <tr>
                                    <td>7</td>
                                    <td>SCHOOL E-MAIL ID</td>
                                    <td><a href="mailto:pcpscbseambegaon@gmail.com">pcpscbseambegaon@gmail.com</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>8</td>
                                    <td>CONTACT DETAILS</td>
                                    <td> 020 - 24363600 / 34363300, 9011032856</td>
                                </tr>
                            </tbody>
                        </table>
                        </p>
                    </div>














                    <div class="post-content">
                        <h3>B. DOCUMENTS AND INFORMATION</h3>
                        <p>
                        <table border="1" cellspacing="0" style="width:100%">
                            <tbody>
                                <tr>
                                    <td class="sl"><strong>SL NO.</strong></td>
                                    <td>
                                        <p><strong>DOCUMENTS AND INFORMATION</strong></p>
                                    </td>
                                    <td><strong>Attachment</strong></td>
                                </tr>
                                
                                <tr>
                                    <td>1</td>
                                    <td>
                                        <p>COPIES OF SOCIETIES/TRUST/COMPANY REGISTRATION/RENEWAL CERTIFICATE, AS
                                            APPLICABLE</p>
                                    </td>
                                    <td><a href="pdf/staff.pdf" target="_blank"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>
                                        <p>COPY OF NO OBJECTION CERTIFICATE (NOC) ISSUED, IF APPLICABLE BY THE STATE
                                            GOVT./UT</p>
                                    </td>
                                    <td><a href="pdf/staff.pdf" target="_blank"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>
                                        <p>COPIES OF RECOGNITION CERTIFICATE UNDER RTE ACT, 2009, AND IT&#39;S RENEWAL
                                            IF APPLICABLE</p>
                                    </td>
                                    <td><a href="pdf/staff.pdf" target="_blank"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>
                                        <p>COPY OF VALID BUILDING SAFETY CERTIFICATE AS PER THE NATIONAL BUILDING CODE
                                        </p>
                                    </td>
                                    <td><a href="pdf/staff.pdf" target="_blank"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>
                                        <p>COPY OF VALID FIRE SAFETY CERTIFICATE ISSUED BY THE COMPETENT AUTHORITY</p>
                                    </td>
                                    <td><a href="pdf/staff.pdf"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                
                                <tr>
                                    <td>6</td>
                                    <td>
                                        <p>COPIES OF VALID WATER, HEALTH AND SANITATION CERTIFICATES</p>
                                    </td>
                                    <td><a href="pdf/staff.pdf" target="_blank"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                <tr>
                                    <td>7</td>
                                    <td>LAND CERTIFICATE</td>
                                    <td><a href="pdf/staff.pdf" target="_blank"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                <tr>
                                    <td>8</td>
                                    <td>COPY OF SELF CERTIFICATION</td>
                                    <td><a href="pdf/staff.pdf" target="_blank"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                            </tbody>
                        </table>
                        </p>
                    </div>














                    <div class="post-content">
                        <h3>C: ACADEMICS DOCUMENTS INFORMATION</h3>
                        <p>
                        <table border="1" style="width:100%">
                            <tbody>
                                <tr>
                                    <td class="sl"><strong>SL NO.</strong></td>
                                    <td><strong>DOCUMENTS/ INFORMATION</strong></td>
                                    <td><strong>Attachments</strong></td>
                                </tr>
                                <tr>
                                    <td><strong>1</strong></td>
                                    <td>FEE STRUCTURE OF THE SCHOOL</td>
                                    <td><a href="pdf/staff.pdf"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                <tr>
                                    <td><strong>2</strong></td>
                                    <td>ANNUAL ACADEMIC CALENDER</td>
                                    <td><a href="pdf/staff.pdf"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                <tr>
                                    <td><strong>3</strong></td>
                                    <td>LIST OF SCHOOL MANAGEMENT COMMITTEE (SMC)</td>
                                    <td><a href="pdf/staff.pdf"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                <tr>
                                    <td><strong>4</strong></td>
                                    <td>LIST OF PARENTS TEACHERS ASSOCIATION EPTA MEMBERS</td>
                                    <td><a href="pdf/staff.pdf" target="_blank"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                
                                <tr>
                                    <td>6</td>
                                    <td>WOMEN&#39;S GRIEVANCE REDRESSAL COMMITTEE</td>
                                    <td><a href="pdf/staff.pdf" target="_blank"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                                <tr>
                                    <td>7</td>
                                    <td>POCSO</td>
                                    <td><a href="pdf/pocso.pdf" target="_blank"><img src="img/pdf.svg" width="25px" alt=""></a></td>
                                </tr>
                            </tbody>
                        </table>
                        </p>
                    </div>














                    














                    
















                    










                </div><!-- single post -->
            </div>

        </div>
    </div>
</section>
<!-- Blog Post End here -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CBSC\cbsc1\cbsc1\resources\views/pages/about/manpubdisclosure.blade.php ENDPATH**/ ?>