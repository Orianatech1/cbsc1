 

<?php $__env->startSection('main-content'); ?>


<!-- Page Header Start here -->
<section class="page-header section-notch">
    <div class="overlay">
        <div class="container">
        <h3>Admission Enquiry</h3>
        <ul>
            <li><a href="<?php echo e(url('/')); ?>">Home /</a></li>
            <li>Admission / Admission Enquiry</li>
        </ul>
        </div><!-- container -->
    </div><!-- overlay -->
    </section><!-- page header -->
    <!-- Page Header End here -->


     <!-- Blog Post Start here -->
     <section class="blog-post padding-120">
        <div class="container">
          <div class="row">
            <div class="col-md-9 post-item-pagination">


                                    <div class="post-items">
                        <div class="post-item">
                                <div class="post-content">
                                          <h3><a href="#">Submit Admission Enquiry</a></h3>
     <form class="contact-form" id="submit_admission" method="post" name="pcps_form" action="https://script.google.com/macros/s/AKfycbzt-fi01PUMVyDfAHPUCS-HnjTwXijmDWrBshTjhOr-XsHeR9E0-6w9-CAXMw4EDubZeQ/exec" >

                        <input type="text" placeholder="Full Name Of Student *" class="contact-input" name="name" id="name" data-error="Name field is required" required>
                                            <br>
                        <input type="text" placeholder="Full Name Of Parent *" class="contact-input" name="parent_name" id="parent_name" data-error="Parent Name field is required" required>


                        <br>

                        <input type="email" placeholder="Email ID Of Parent *" class="contact-input" name="email" id="email" data-error="Email field is required" required>
                        <input type="text" placeholder="Phone Of Parent*" class="contact-input" name="phone" id="phone" data-error="Phone field is required" required>
                        <select id="city" class='contact-input' name="city">
                            <option selected="selected">-Select City-</option>
                            <option disabled="disabled" style="background-color:#3E3E3E"><font color="#000000"><i>-Top Cities-</i></font></option>
                            <option>Pune</option>
                            <option>Mumbai</option>

                            <option>Other</option>
                        </select>

                    <select id="standard" class='contact-input' name="standard">
                            <option selected="selected">-Select Standard For Which Admission Is Required-</option>
                            <option>Nursery</option>
                            <option>Jr.KG</option>
                            <option>Sr.KG</option>
                            <option>Class 1</option>
                            <option>Class 2</option>
                            <option>Class 3</option>
                            <option>Class 4</option>
                            <option>Class 5</option>
                            <option>Class 6</option>
                            <option>Class 7</option>
                            <option>Class 8</option>
                            <option>Class 9</option>
                            <option>Class 10</option>
                    </select>
                    <input type="text" placeholder="Marks Obtained In Pervious Standard *" class="contact-input" name="marks" id="marks">

<script>

const scriptURL = 'https://script.google.com/macros/s/AKfycbzt-fi01PUMVyDfAHPUCS-HnjTwXijmDWrBshTjhOr-XsHeR9E0-6w9-CAXMw4EDubZeQ/exec'

const form = document.forms['pcps_form']

form.addEventListener('submit', e => {
  e.preventDefault()
  fetch(scriptURL, { method: 'POST', body: new FormData(form)})
  .then(response => alert("Thank you! your form is submitted successfully." ))
  .then(() => { window.location.reload(); })
  .catch(error => console.error('Error!', error.message))
})

</script>
                        

                        


                        <input type="hidden" name="_token" value="">


                        <input type="submit" class="contact-button" value="Submit" >

                    </form>

    <script src="js/jquery.min.js"></script>
    <script src="js/sweetalert.min.js"></script>
    

                                </div>
                        </div><!-- post item -->
                    </div><!-- post items -->



            </div>
            <div class="col-md-3">
              <div class="sidebar">

                <div class="sidebar-item">
                  <h3 class="sidebar-title">Admissions</h3>

                  <ul class="sidebar-categories">
                                                <li><a href="<?php echo e(url('/admission-enquiry')); ?>">Admission Enquiry</a></li>
                                                <li><a href="<?php echo e(url('/admission-procedure-age-criteria')); ?>">Admission Procedure &amp; Age Criteria</a></li>
                                                <li><a href="<?php echo e(url('/doucment-checklist')); ?>">Document Checklist</a></li>
                                                <li><a href="<?php echo e(url('/fee-details')); ?>">Fee Details</a></li>

                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
        <!-- Blog Post End here -->


              <script src="js/jquery.min.js"></script>
          <script src="js/sweetalert.min.js"></script>
          <script>
          $(document).ready(function(){
              $('#submit_admission').on('submit', function(event){
              event.preventDefault();
              $.ajax({
              url:"/submit_admission_enquiry",
              method:"POST",
              data:new FormData(this),
              dataType:'JSON',
              contentType: false,
              cache: false,
              processData: false,
              success:function(data)
              {
              swal("Successfully Inserted !!!", "We Will Contact You Soon.", "success");
              $('#submit_admission input[type="text"]').val('');
              $('#submit_admission input[type="email"]').val('');
              location.reload();
              }
              })
              });
          });
          </script>








 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CBSC\cbsc1\cbsc1\resources\views/pages/admissions/admission-enquiry.blade.php ENDPATH**/ ?>