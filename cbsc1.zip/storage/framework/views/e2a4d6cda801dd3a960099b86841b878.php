<?php $__env->startSection('main-content'); ?>




  <script src="../ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="../unpkg.com/sweetalert%402.1.2/dist/sweetalert.min.js"></script>
  



  <!-- Banner Start here -->
  <section class="banner banner-two" id="mySliderSection">

    <div class="banner-slider swiper-container" style="width:100% !important; height: 600px !important;">
      <div class="swiper-wrapper">



        <div style="background:url('storage/Homepage/Slider/1721208807IMG-20240717-WA0013%20(1.html) (1).jpg ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->

        <div style="background:url('storage/Homepage/Slider/17158484021630a9dd59c7497890b10fed8e03a5f8.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->

        <div style="background:url('storage/Homepage/Slider/171584839019bd21f73d444489a87080d8ee5ceb5b.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->

        <div style="background:url('storage/Homepage/Slider/1713250554slider.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Graduation Day 2024 </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->

        <div style="background:url('storage/Homepage/Slider/1713250951Slider1.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Summer Camp 2024 </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->

        <div style="background:url('storage/Homepage/Slider/1708055823IMG-20240216-WA0000%20(1.html) (1).jpg ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->

        <div
          style="background:url('storage/Homepage/Slider/1697783719WhatsApp%20Image%202023-10-19%20at%201.34.16%20AM.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Math Exhibition 2023 </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->

        <div style="background:url('storage/Homepage/Slider/1696687823IMG-20230921-WA0023%20(1.html).jpg ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Ganpati Celebration </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->

        <div style="background:url('storage/Homepage/Slider/1696404082WA0032.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> EGN Education Awards </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->

        <div style="background:url('storage/Homepage/Slider/1691568671IMG-20230808-WA0015%20(1.html).jpg ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> A Place To Learn And Celebrate Success Under Dynamic Leadership </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/16904399521690428891IMG-20230722-WA0010 (1).webp '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/16904399521690428891IMG-20230722-WA0010%20(1.html).webp ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Award for Peace Ambassador </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1673253503IMG-20221201-WA0009 (1) (1).jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1673253503IMG-20221201-WA0009%20(1.html) (1).jpg ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Shiksha Gaurav Puraskar 2022 </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1677028756Cygnet Planetarium.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1677028756Cygnet%20Planetarium.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Planetarium </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1687422530IMG-20230621-WA0083 (2) (1).jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1687422530IMG-20230621-WA0083%20(2.html) (1).jpg ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Yoga Day </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1687925289IMG-20230625-WA0024 (1) (1).jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1687925289IMG-20230625-WA0024%20(1.html) (1).jpg ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Ace Of Initiative Award </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1681273304IMG-20230411-WA0027.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1681273304IMG-20230411-WA0027.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Self Sustained Campus Supporting All Activity </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1666148397IMG-2022101 vv.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1666148397IMG-2022101%20vv.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Educational Excursion to Dr. Suresh Naik Space Spark </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/16703041001667926061pp.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/16703041001667926061pp.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> IKA- 2022 </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1669093266IMG-20221104-WA0036.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1669093266IMG-20221104-WA0036.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Sports </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1669093338IMG-20221109-WA0009.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1669093338IMG-20221109-WA0009.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Sports </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/16904401051682309320IMG-20230424-WA0012 (2) (1).webp '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div
          style="background:url('storage/Homepage/Slider/16904401051682309320IMG-20230424-WA0012%20(2.html) (1).webp ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Award By ISKON </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1679028475pf.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1679028475pf.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Science Exhibition 2022-23 </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1706850785home slider.jpeg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1706850785home%20slider.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Republic Day Celebration </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1706852304slider.JPG '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1706852304slider.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Cultural Grooming For National Integrity </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1706852469home slider annaul day.JPG '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1706852469home%20slider%20annaul%20day.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Annual Day 2023-24 </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/166365996216002604002.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/166365996216002604002.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Well Equipped Laboratories </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1682755606WhatsApp Image 2023-04-19 at 08.53.30 (1).jpeg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div
          style="background:url('storage/Homepage/Slider/1682755606WhatsApp%20Image%202023-04-19%20at%2008.53.html).jpeg ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Summer Day Out Of Little Ones </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/16636599971660713277rsz_1img-20220812-wa0010.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/16636599971660713277rsz_1img-20220812-wa0010.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Music Increases Coordination Promote Emotional Developement Mastering Memorization </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1666180274labrary.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1666180274labrary.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Library To Enrich Intellectual Aesthetic Cultural And Emotional Growth </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/16636600131663658398IMG_9895 (3) (1).jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/16636600131663658398IMG_9895%20(3.html) (1).jpg ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Cultural Grooming For National Integrity </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1669094261IMG-20220810-WA0067vv.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1669094261IMG-20220810-WA0067vv.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Sports Ensuring Team Spirit And Leadership </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1679030218classroom (2).jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1679030218classroom%20(2.html).jpg ');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Class Room </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1672905831IMG-20230105-WA0036.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1672905831IMG-20230105-WA0036.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Class Room </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1672973835IMG-20230105-WA0033.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1672973835IMG-20230105-WA0033.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Class Room </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1672973870IMG-20230105-WA0034.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1672973870IMG-20230105-WA0034.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> Class Room </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->
        <!--<div style="background:url('/storage/Homepage/Slider/1675871231We are onw team photo.jpg '); height:440px; !important" class="banner-item slide-one swiper-slide" >-->
        <div style="background:url('storage/Homepage/Slider/1675871231We%20are%20onw%20team%20photo.jpg');"
          class="banner-item slide-one swiper-slide">
          <div class="banner-overlay"></div>
          <div class="container" style="min-height:200px !important;">
            <div class="banner-content">
              <h3> We Are One -Team Pune Cambridge </h3>
            </div><!-- banner-content -->
          </div><!-- container -->
        </div><!-- slide item -->

      </div><!-- swiper-wrapper -->
      <div class="swiper-pagination"></div>
    </div><!-- swiper-container -->
  </section><!-- banner -->
  <!-- Banner End here -->


  <!-- facility Start here -->
  <section class="facility facility-two">
    <div class="container">
      <div class="facility-items">
        <!-- facility item -->
        <div class="facility-item">
            <div class="front-part">
              <span class="icon-two flaticon-line-chart"></span>
              <h4><a href="facility_details/4.html">
                  <font color="white">School USP</font>
                </a></h4>
            </div>
            <div class="back-part">
              <span class="icon-two flaticon-line-chart"></span>
              <h4><a href="facility_details/4.html">
                  <font color="white">School USP</font>
                </a></h4>
              <p>Affordable fees for students with provision for parents to pay fee in installments.</p>
            </div>
          </div>
          <!-- facility item -->
          <div class="facility-item">
            <div class="front-part">
              <span class="icon-two flaticon-avatar"></span>
              <h4><a href="facility_details/2.html">
                  <font color="white">Assessment</font>
                </a></h4>
            </div>
            <div class="back-part">
              <span class="icon-two flaticon-avatar"></span>
              <h4><a href="facility_details/2.html">
                  <font color="white">Assessment</font>
                </a></h4>
              <p>Assessments are a continuous process, conducted on weekly, monthly termwise.</p>
            </div>
          </div>
        <div class="facility-item">
          <div class="front-part">
            <span class="icon-two flaticon-symbols"></span>
            <h4><a href="facility_details/6.html">
                <font color="white">Pedagogy</font>
              </a></h4>
          </div>
          <div class="back-part">
            <span class="icon-two flaticon-symbols"></span>
            <h4><a href="facility_details/6.html">
                <font color="white">Pedagogy</font>
              </a></h4>
            <p>The pedagogical practices at BPSN are learner centric.</p>
          </div>
        </div>


        <!-- facility item -->
        <div class="facility-item">
          <div class="front-part">
            <span class="icon-two flaticon-pen"></span>
            <h4><a href="facility_details/3.html">
                <font color="white">Final Evaluation</font>
              </a></h4>
          </div>
          <div class="back-part">
            <span class="icon-two flaticon-pen"></span>
            <h4><a href="facility_details/3.html">
                <font color="white">Final Evaluation</font>
              </a></h4>
            <p>Evaluation includes written exam, notebook submission, and subject enrichment activities.</p>
          </div>
        </div>


        <!-- facility item -->

      </div><!-- facility items -->
    </div><!-- container -->
  </section><!-- facility -->
  <!-- facility End here -->


  <!-- Event Start here -->
  
  <!-- event blog -->
  <!-- event End here -->

  <!-- facility Start here -->
  <!-- facility End here -->

  <!-- Features Start here -->
  <section class="features padding-120">
    <div class="container">
      <div class="section-header">
        <h3>Why Choose Pune Cambridge?</h3>
      </div>
      <div class="row">
        <div class="col-lg-4 col-xs-12">
          <div class="features-left">
            <div class="feature-item">
              <div class="icon flaticon-people-1"></div>
              <div class="content">
                <h4>Sports Facilities</h4>
                <p>Sports and games curriculum is an integral and compulsory part of the education process. </p>
              </div>
            </div>
            <div class="feature-item">
              <div class="icon flaticon-symbols"></div>
              <div class="content">
                <h4>ICT Facilities</h4>
                <p>Information and Communication Technology to enhance, optimise the delivery of information. </p>
              </div>
            </div>
            <div class="feature-item">
              <div class="icon flaticon-microphone"></div>
              <div class="content">
                <h4>Music And Art Club</h4>
                <p>Clubs are an essential element of life as they offer our pupils to engage in exciting new challenges.
                </p>
              </div>
            </div>
          </div><!-- feature left -->
        </div>
        <div class="col-lg-4 col-xs-12">
          <div class="feature-image">
            <img src="storage/Homepage/WhyCPSNImage/160043241216003130396.jpg" alt="feature image"
              class="img-responsive" style="height: 360px; width:360px;">
          </div>
        </div>
        <div class="col-lg-4 col-xs-12">
          <div class="features-right">
            <div class="feature-item">
              <div class="icon flaticon-home"></div>
              <div class="content">
                <h4>Transport</h4>
                <p>The school provides transportation facilities to students. Buses are operated in all routes. </p>
              </div>
            </div>
            <div class="feature-item">
              <div class="icon flaticon-line-chart"></div>
              <div class="content">
                <h4>Modern Library</h4>
                <p>School Library has an indispensable role in a school setting. It is where independent learning is
                  facilitated. </p>
              </div>
            </div>
            <div class="feature-item">
              <div class="icon flaticon-signs"></div>
              <div class="content">
                <h4>Equipped Laboratories</h4>
                <p>Laboratory provides the first-hand experience to develop skills necessary for study and research.
                </p>
              </div>
            </div>
          </div><!-- feature left -->
        </div>
      </div><!-- row -->
    </div><!-- container -->
  </section><!-- features -->
  <!-- Features End here -->

  <!-- Gallery Start here -->
  <section class="gallery gallery-two">
    <div class="overlay padding-120">
      <div class="section-header bg">
        <h3>Our School Gallery</h3>
      </div>
      <div class="gallery-two-items">

        <div class="gallery-item">
          <div class="gallery-image">
            <img src="storage/photo_gallery/2/1721213414IMG-20240717-WA0030.jpg"
              alt="/storage/photo_gallery/2/1721213414IMG-20240717-WA0030.jpg" class="img-responsive">
            <div class="gallery-overlay">
              <div class="bg"></div>
            </div>
            <div class="gallery-content">
              <a href="storage/photo_gallery/2/1721213414IMG-20240717-WA0030.jpg" data-rel="lightcase:myCollection"><i
                  class="icon flaticon-expand"></i></a>
              <h4></h4>
            </div>
          </div>
        </div>
        <div class="gallery-item">
          <div class="gallery-image">
            <img src="storage/photo_gallery/2/1721213414IMG-20240717-WA0021.jpg"
              alt="/storage/photo_gallery/2/1721213414IMG-20240717-WA0021.jpg" class="img-responsive">
            <div class="gallery-overlay">
              <div class="bg"></div>
            </div>
            <div class="gallery-content">
              <a href="storage/photo_gallery/2/1721213414IMG-20240717-WA0021.jpg" data-rel="lightcase:myCollection"><i
                  class="icon flaticon-expand"></i></a>
              <h4></h4>
            </div>
          </div>
        </div>
        <div class="gallery-item">
          <div class="gallery-image">
            <img src="storage/photo_gallery/2/1721213414IMG-20240717-WA0020.jpg"
              alt="/storage/photo_gallery/2/1721213414IMG-20240717-WA0020.jpg" class="img-responsive">
            <div class="gallery-overlay">
              <div class="bg"></div>
            </div>
            <div class="gallery-content">
              <a href="storage/photo_gallery/2/1721213414IMG-20240717-WA0020.jpg" data-rel="lightcase:myCollection"><i
                  class="icon flaticon-expand"></i></a>
              <h4></h4>
            </div>
          </div>
        </div>
        <div class="gallery-item">
          <div class="gallery-image">
            <img src="storage/photo_gallery/2/1721213414IMG-20240717-WA0018.jpg"
              alt="/storage/photo_gallery/2/1721213414IMG-20240717-WA0018.jpg" class="img-responsive">
            <div class="gallery-overlay">
              <div class="bg"></div>
            </div>
            <div class="gallery-content">
              <a href="storage/photo_gallery/2/1721213414IMG-20240717-WA0018.jpg" data-rel="lightcase:myCollection"><i
                  class="icon flaticon-expand"></i></a>
              <h4></h4>
            </div>
          </div>
        </div>

      </div><!-- gallery items -->

      <div class="gallery-button"><a href="Gallery/photo_gallery_display.html" class="button-default">View More
          Gallery</a></div>

    </div><!-- overlay -->
  </section><!-- gallery -->
  <!-- Gallery End here -->

  <!-- Achievements Start here -->
  <section class="achievements">
    <div class="overlay padding-120">
      <div class="container">
        <div class="row">

          <div class="col-md-3 col-sm-3 col-12">
            <div class="achievement-item">
              <i class="icon flaticon-student"></i>
              <span class="counter">320</span><span>+</span>
              <p>Total Students</p>
            </div><!-- achievement item -->
          </div>
          <div class="col-md-3 col-sm-3 col-12">
            <div class="achievement-item">
              <i class="icon flaticon-construction"></i>
              <span class="counter">12</span><span>+</span>
              <p>Class Rooms</p>
            </div><!-- achievement item -->
          </div>
          <div class="col-md-3 col-sm-3 col-12">
            <div class="achievement-item">
              <i class="icon flaticon-school-bus"></i>
              <span class="counter">24</span><span>+</span>
              <p>School Bus</p>
            </div><!-- achievement item -->
          </div>
          <div class="col-md-3 col-sm-3 col-12">
            <div class="achievement-item">
              <i class="icon flaticon-people"></i>
              <span class="counter">100</span><span>+</span>
              <p>Total Teachers</p>
            </div><!-- achievement item -->
          </div>
        </div><!-- row -->
      </div><!-- container -->
    </div><!-- overlay -->
  </section><!-- achievements -->
  <!-- Achievements End here -->


  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CBSC\cbsclaravel\cbsc\resources\views/welcome.blade.php ENDPATH**/ ?>