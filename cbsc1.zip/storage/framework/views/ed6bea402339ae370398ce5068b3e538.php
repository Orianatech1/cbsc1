<?php $__env->startSection('main-content'); ?>


<section class="page-header section-notch">
    <div class="overlay">
        <div class="container">
            <h3>Vission & Mission</h3>
            <ul>
                <li><a href="<?php echo e(url('/')); ?>">Home /</a></li>
                <li>About / Vission & Mission</li>
            </ul>
        </div><!-- container -->
    </div><!-- overlay -->
</section><!-- page header -->
<!-- Page Header End here -->

<!-- Blog Post Start here -->
<section class="blog-post padding-120">
    <div class="container">
        <div class="row">

            <div class="col-lg-12">
                <div class="single-post ">








                    <div class="post-content">
                        <h3>Vision</h3>
                        <p>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Cumque vel a accusantium nihil libero? Vero hic doloribus qui quos molestias, totam possimus, quam illum obcaecati laborum odit velit excepturi quasi.</p>
                        </p>
                    </div>














                    <div class="post-content">
                        <h3>Mission</h3>
                        <p>
                            <style>
                                .single-post .post-content {
                                    margin-bottom: 20px;
                                    border-top: 1px solid #f0f0f0;
                                }
                            </style>
                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nulla nisi similique saepe distinctio autem reprehenderit soluta, accusamus culpa. Commodi voluptatibus tenetur neque asperiores qui sunt tempore obcaecati laboriosam minima alias.</p>
                        </p>
                    </div>










                </div><!-- single post -->
            </div>

        </div>
    </div>
</section>
<!-- Blog Post End here -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CBSC\cbsc1\cbsc1\resources\views/pages/about/vissionmission.blade.php ENDPATH**/ ?>